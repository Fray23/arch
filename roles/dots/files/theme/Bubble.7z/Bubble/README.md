# Bubble GTK Themes
Gtk2, Gtk3, Gnome shell, Metacity, Xfwm4 theme base on [Arc-Theme](https://github.com/horst3180/arc-theme)</br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br></br>
Theme can be download [here](https://www.pling.com/p/1253999/)</br></br>
Screenshots:</br>
![BubbleScreenshots](https://i.ibb.co/rvPQLLJ/bubble-blue-screenshots.png "BubbleScreenshots")</br></br>
